# AQI Prediction 

**This project demonstrates the prediciton of AQI indext provied past 5 hours of data using machine learning.**

Algorithm Used : 
1. LSTM

![alt text](model.png)

Team Member:
1. Manisha Bhandari

The LSTM architecture used is :